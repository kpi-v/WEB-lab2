function Shorten_btn(){
    showAlert("<strong>Зауваження:</strong> програмувати функціональність сайту не потрібно (!)");
}