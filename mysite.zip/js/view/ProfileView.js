export class ProfileView {
    constructor() {
        this.nameContainer = document.getElementById('profile-name');
        this.tabContainer = document.getElementById('url-table-body');
        this.updateBtn = document.getElementById('update-profile-btn');
        this.cancelBtn = document.getElementById('cancel-profile-btn');
    }

    renderUserName(user) {
        if (this.nameContainer && user?.name) {
            this.nameContainer.textContent = `Hello, ${user.name}`;
        }

        const nameField = document.querySelector('#name');
        const emailField = document.querySelector('#email');
        const genderField = document.querySelector('#gender');
        const bdayField = document.querySelector('#bday');

        if (nameField) nameField.value = user.name || '';
        if (emailField) emailField.value = user.email || '';
        if (genderField) genderField.value = user.gender || '';
        if (bdayField) bdayField.value = user.bday || '';

        this.disableUpdateButton();
    }

    bindUpdateProfile(handler) {
        this.updateBtn?.addEventListener('click', () => {
            const updatedUser = {
                name: document.querySelector('#name')?.value.trim(),
                email: document.querySelector('#email')?.value.trim(),
                gender: document.querySelector('#gender')?.value,
                bday: document.querySelector('#bday')?.value
            };
            handler(updatedUser);
        });
    }

    bindProfileChangeDetection(originalUser) {
        const fields = ['name', 'email', 'gender', 'bday'].map(id => document.querySelector(`#${id}`));
        const compare = () => {
            const changed = fields.some(field => {
                if (!field) return false;
                return field.value.trim() !== (originalUser[field.id] || '');
            });
            this.updateBtn.disabled = !changed;
        };
        fields.forEach(field => field?.addEventListener('input', compare));
        compare(); // Initial state
    }

    bindProfileCancel(originalUser) {
        this.cancelBtn?.addEventListener('click', () => {
            const userFromStorage = JSON.parse(localStorage.getItem('loggedInUser')) || originalUser;
            this.renderUserName(userFromStorage);
            this.disableUpdateButton();
        });
    }

    disableUpdateButton() {
        if (this.updateBtn) this.updateBtn.disabled = true;
    }

    renderUrlTable(urls) {
        if (!this.tabContainer) return;
        this.tabContainer.innerHTML = '';
        urls.forEach(({ short, original }, index) => {
            const row = document.createElement('tr');
            row.innerHTML = `
        <td>${index + 1}</td>
        <td>${original}</td>
        <td><a href="${short}" target="_blank">${short}</a></td>
      `;
            this.tabContainer.appendChild(row);
        });
    }
}
