function save_btn(){
    showAlert("<strong>Зауваження:</strong> програмувати функціональність сайту не потрібно (!)");
}

function cancle_btn(){
    showAlert("<strong>Зауваження:</strong> програмувати функціональність сайту не потрібно (!)");
}