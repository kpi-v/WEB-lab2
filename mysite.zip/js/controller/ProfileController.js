import { ProfileView } from '../view/ProfileView.js';
import { AlertView } from '../view/AlertView.js';

export class ProfileController {
  constructor() {
    this.view = new ProfileView();
    this.alert = new AlertView();
    this.user = JSON.parse(localStorage.getItem('loggedInUser'));
    const urls = JSON.parse(localStorage.getItem('shortenedUrls') || '[]');

    if (!this.user) {
      window.location.href = 'login.html';
      return;
    }

    this.view.renderUserName(this.user);
    this.view.renderUrlTable(urls);
    this.view.bindUpdateProfile(this.handleUpdate.bind(this));
    this.view.bindProfileChangeDetection(this.user);
    this.view.bindProfileCancel(() => this.view.renderUserName(this.user));

    const logoutBtn = document.getElementById('logout-btn');
    if (logoutBtn) {
      logoutBtn.addEventListener('click', () => {
        localStorage.removeItem('loggedInUser');
        window.location.href = 'login.html';
      });
    }
  }

  handleUpdate(updatedUser) {
    if (!updatedUser.name || !updatedUser.email) {
      this.alert.show('Name and Email are required.', 'danger');
      return;
    }
    this.user = { ...this.user, ...updatedUser };
    localStorage.setItem('loggedInUser', JSON.stringify(this.user));
    this.view.renderUserName(this.user);
    this.alert.show('Profile updated.', 'success');
    this.view.disableUpdateButton();
  }
}
